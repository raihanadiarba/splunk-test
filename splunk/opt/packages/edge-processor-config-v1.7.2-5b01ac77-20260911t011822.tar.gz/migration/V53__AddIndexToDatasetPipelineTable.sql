/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

CREATE INDEX dataset_pipeline_pipeline_id_node_id_tenant_id ON dataset_pipeline (tenant_id, pipeline_id, node_id);