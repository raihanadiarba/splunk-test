/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

CREATE TABLE deleted_cache (
    id             VARCHAR(36) PRIMARY KEY,
    tenant_id      VARCHAR(1024) NOT NULL,
    deleted_at     bigint NOT NULL
);