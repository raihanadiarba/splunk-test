/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

CREATE TABLE rulesets
(
    tenant_id   VARCHAR(1024) NOT NULL,
    id          VARCHAR(36)   NOT NULL,
    name        text NOT NULL,
    description text NOT NULL,
    spl         text NOT NULL,
    created     bigint NOT NULL,
    modified    bigint NOT NULL,
    CONSTRAINT pk_ruleset_tenant_id_id PRIMARY KEY (tenant_id, id)
);

ALTER TABLE node ADD COLUMN ruleset_id VARCHAR(36) NOT NULL;