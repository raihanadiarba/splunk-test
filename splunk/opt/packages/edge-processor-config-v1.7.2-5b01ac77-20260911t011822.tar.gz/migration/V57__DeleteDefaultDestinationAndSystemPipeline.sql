/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

/*
Deletes all default desination and system pipelines
*/

DELETE FROM pipelines WHERE id LIKE 'default_destination_%';
DELETE FROM pipelines WHERE id LIKE 'system_pipeline_%';