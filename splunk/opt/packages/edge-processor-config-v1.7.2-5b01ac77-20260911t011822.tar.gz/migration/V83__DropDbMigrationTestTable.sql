/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */
DROP TABLE db_migration_test;