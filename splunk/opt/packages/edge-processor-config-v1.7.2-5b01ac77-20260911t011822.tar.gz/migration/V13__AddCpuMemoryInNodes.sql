/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes
    ADD COLUMN cpu_cores decimal,
    ADD COLUMN memory_mbs bigint;

UPDATE nodes SET cpu_cores = 1.0 WHERE cpu_cores IS NULL; -- 1 cpu core by default
UPDATE nodes SET memory_mbs = 1024 WHERE memory_mbs IS NULL; -- 1 GiB by default

ALTER TABLE nodes
    ALTER COLUMN cpu_cores SET NOT NULL,
    ALTER COLUMN memory_mbs SET NOT NULL;
