/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE global_configs
    ADD COLUMN forwarder_max_channels int NOT NULL DEFAULT 100,
    ADD COLUMN forwarder_port int NOT NULL DEFAULT 9997;
