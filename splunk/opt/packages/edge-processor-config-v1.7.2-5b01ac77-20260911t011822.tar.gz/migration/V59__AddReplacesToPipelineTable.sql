/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE pipelines
    ADD COLUMN replaces VARCHAR(36) DEFAULT NULL;
