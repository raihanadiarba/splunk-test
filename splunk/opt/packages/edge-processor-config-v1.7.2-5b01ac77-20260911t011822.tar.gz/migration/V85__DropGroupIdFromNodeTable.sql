/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

 ALTER TABLE nodes DROP COLUMN group_id;
