/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

CREATE TABLE dataset (
    id          VARCHAR(64) NOT NULL PRIMARY KEY,
    kind        text
);