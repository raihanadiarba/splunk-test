UPDATE nodes
SET receivers_config = '[ {"receiverName": "s2s", "enableReceiver": "true", "enableTLSForReceiver": "false"} ]'
WHERE receivers_config IS NULL
  AND (server_certificate IS NULL OR ca_certificate IS NULL OR vault_path IS NULL);

UPDATE nodes
SET receivers_config = '[ {"receiverName": "s2s", "enableReceiver": "true", "enableTLSForReceiver": "true"} ]'
WHERE server_certificate IS NOT NULL
  AND ca_certificate IS NOT NULL
  AND vault_path IS NOT NULL;