/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes ADD COLUMN service_principal text DEFAULT null;
ALTER TABLE nodes ADD COLUMN principal_key_id text DEFAULT null;
