/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes DROP COLUMN service_principal;
ALTER TABLE nodes DROP COLUMN principal_key_id;
