/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

/*
 * Migrate enableTLS -> tlsOption if tlsOption value is null or empty:
 * - if enableTLS is false, tlsOption is set to disabled
 * - if enableTLS is true, tlsOption is set to mTLS
 */

UPDATE nodes
SET source_configs = jsonb_set(source_configs, '{s2s,tlsOption}', '"disabled"')
WHERE (source_configs -> 's2s' ->> 'enableTLS')::boolean IS NOT TRUE AND (source_configs -> 's2s' ->> 'tlsOption' = '') IS NOT FALSE;

UPDATE nodes
SET source_configs = jsonb_set(source_configs, '{s2s,tlsOption}', '"mTLS"')
WHERE (source_configs -> 's2s' ->> 'enableTLS')::boolean IS TRUE AND (source_configs -> 's2s' ->> 'tlsOption' = '') IS NOT FALSE;

UPDATE nodes
SET source_configs = jsonb_set(source_configs, '{hecreceiver,tlsOption}', '"disabled"')
WHERE (source_configs -> 'hecreceiver' ->> 'enableTLS')::boolean IS NOT TRUE AND (source_configs -> 'hecreceiver' ->> 'tlsOption' = '') IS NOT FALSE;

UPDATE nodes
SET source_configs = jsonb_set(source_configs, '{hecreceiver,tlsOption}', '"mTLS"')
WHERE (source_configs -> 'hecreceiver' ->> 'enableTLS')::boolean IS TRUE AND (source_configs -> 'hecreceiver' ->> 'tlsOption' = '') IS NOT FALSE;

UPDATE nodes
SET source_configs = jsonb_set(source_configs, '{syslog,tlsOption}', '"disabled"')
WHERE (source_configs -> 'syslog' ->> 'enableTLS')::boolean IS NOT TRUE AND (source_configs -> 'syslog' ->> 'tlsOption' = '') IS NOT FALSE;

UPDATE nodes
SET source_configs = jsonb_set(source_configs, '{syslog,tlsOption}', '"mTLS"')
WHERE (source_configs -> 'syslog' ->> 'enableTLS')::boolean IS TRUE AND (source_configs -> 'syslog' ->> 'tlsOption' = '') IS NOT FALSE;