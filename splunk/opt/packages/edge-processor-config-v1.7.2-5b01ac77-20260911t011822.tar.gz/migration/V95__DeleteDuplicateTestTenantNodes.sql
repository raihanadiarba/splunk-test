/*
 * Copyright (c) 2026 Splunk, Inc. All rights reserved.
 */

DELETE FROM nodes
WHERE (tenant_id, id) IN (
  SELECT tenant_id, id
  FROM (
    SELECT tenant_id, id,
           ROW_NUMBER() OVER (PARTITION BY name, tenant_id ORDER BY created ASC) AS rn
    FROM nodes
    WHERE tenant_id = 'testsscmonitorrunscope'
       OR tenant_id LIKE 'extmonscs%'
  ) ranked
  WHERE rn > 1
);
