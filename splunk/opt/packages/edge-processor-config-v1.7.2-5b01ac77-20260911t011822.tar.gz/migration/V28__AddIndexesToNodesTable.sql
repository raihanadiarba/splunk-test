CREATE INDEX nodes_tenant_nodeid ON nodes (tenant_id, id);
CREATE INDEX nodes_tenant ON nodes (tenant_id);
