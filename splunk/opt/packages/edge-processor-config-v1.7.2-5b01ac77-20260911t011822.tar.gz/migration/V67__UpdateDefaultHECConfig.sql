/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

UPDATE global_configs
SET hec_config = '{"port": 8088}'
WHERE hec_config IS NULL;