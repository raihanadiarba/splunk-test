/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE global_configs
    ADD COLUMN cpu_warning_threshold decimal NOT NULL DEFAULT 80,
    ADD COLUMN mem_warning_threshold decimal NOT NULL DEFAULT 80;
