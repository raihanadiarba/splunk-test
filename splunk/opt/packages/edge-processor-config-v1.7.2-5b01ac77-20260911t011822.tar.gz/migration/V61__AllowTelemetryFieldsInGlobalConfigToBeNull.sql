/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE global_configs ALTER COLUMN telemetry_indexers_dataset DROP NOT NULL;