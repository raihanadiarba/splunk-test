/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */


CREATE TABLE dataset_pipeline (
    tenant_id    VARCHAR(36) NOT NULL,
    dataset_id   VARCHAR(64) NOT NULL,
    pipeline_id  VARCHAR(36) NOT NULL,
    node_id      VARCHAR(36) NOT NULL,
    CONSTRAINT pk_dataset_id_pipeline_id_tenant_id PRIMARY KEY (tenant_id, dataset_id, pipeline_id),
    FOREIGN KEY (dataset_id) REFERENCES dataset (id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (tenant_id, pipeline_id, node_id) references pipelines (tenant_id, id, node_id) ON UPDATE CASCADE ON DELETE CASCADE
);