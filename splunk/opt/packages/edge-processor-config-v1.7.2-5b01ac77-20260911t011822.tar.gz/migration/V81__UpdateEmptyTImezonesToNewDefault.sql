/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

/*
* We are no longer supporting the empty timezone. Migrate all timezones that are currently empty
* to instead have Etc/UTC as their timezone.
*/

UPDATE global_configs
SET timezone = 'Etc/UTC'
WHERE timezone = '';