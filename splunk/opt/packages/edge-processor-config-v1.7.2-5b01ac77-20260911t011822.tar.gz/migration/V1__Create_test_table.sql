CREATE TABLE db_migration_test (
    id varchar(36) NOT NULL
);
