/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE dataset_pipeline DROP CONSTRAINT dataset_pipeline_dataset_id_fkey;
DROP TABLE dataset;