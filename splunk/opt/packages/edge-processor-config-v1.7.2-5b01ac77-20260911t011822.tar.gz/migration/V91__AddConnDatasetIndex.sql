/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */
CREATE INDEX idx_connection_dataset_pipeline_dataset_tenant ON connection_dataset_pipeline (tenant_id, dataset_id);

CREATE INDEX idx_connection_dataset_pipeline_tenant_pipeline_node ON connection_dataset_pipeline (tenant_id, pipeline_id, node_id);
