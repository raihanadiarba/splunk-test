ALTER TABLE nodes ADD COLUMN source_configs jsonb;

UPDATE nodes
SET source_configs = '{"s2s": {"enable": "true", "enableTLS": "false"}}'
WHERE source_configs IS NULL
  AND (server_certificate IS NULL OR ca_certificate IS NULL OR vault_path IS NULL);

UPDATE nodes
SET source_configs = '{"s2s": {"enable": "true", "enableTLS": "true"}}'
WHERE server_certificate IS NOT NULL
  AND ca_certificate IS NOT NULL
  AND vault_path IS NOT NULL;