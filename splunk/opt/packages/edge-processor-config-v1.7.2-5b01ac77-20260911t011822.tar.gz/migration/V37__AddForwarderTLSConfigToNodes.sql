ALTER TABLE nodes
    ADD COLUMN server_certificate text,
    ADD COLUMN ca_certificate text,
    ADD COLUMN vault_path text;
