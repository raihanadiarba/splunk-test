/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

/*
Align the length of the column with the pipelines.id
*/

ALTER TABLE dataset_pipeline ALTER COLUMN pipeline_id TYPE VARCHAR(64);