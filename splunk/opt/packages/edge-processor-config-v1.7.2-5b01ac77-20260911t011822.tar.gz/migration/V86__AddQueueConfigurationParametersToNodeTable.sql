/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes ADD COLUMN durable_queue_enabled BOOLEAN DEFAULT true;
ALTER TABLE nodes ADD COLUMN durable_queue_gb INTEGER DEFAULT 1;
