/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE lb_rule ADD COLUMN version bigint DEFAULT 0;