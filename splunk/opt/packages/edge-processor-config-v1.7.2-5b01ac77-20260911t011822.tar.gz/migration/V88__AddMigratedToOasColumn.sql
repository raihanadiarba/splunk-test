/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes ADD COLUMN migrated_to_oas BOOLEAN DEFAULT false;
