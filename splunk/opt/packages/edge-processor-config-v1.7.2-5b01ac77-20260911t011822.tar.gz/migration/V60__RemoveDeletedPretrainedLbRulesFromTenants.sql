/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

DELETE FROM lb_rule WHERE id = '333206b1-48d8-4d10-a993-d5c4615e9343' OR id = 'f896118f-3dd3-469d-9eee-582001f98fb7' OR id = '07ede881-7321-4955-a1ef-f98084bc302f';
