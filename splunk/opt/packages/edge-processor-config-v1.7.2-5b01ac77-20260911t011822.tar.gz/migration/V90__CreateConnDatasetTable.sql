/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */

CREATE TABLE connection_dataset_pipeline (
      tenant_id       VARCHAR(36) NOT NULL,
      connection_id   VARCHAR(64) NOT NULL,
      dataset_id      VARCHAR(64) NOT NULL,
      pipeline_id     VARCHAR(36) NOT NULL,
      node_id         VARCHAR(36) NOT NULL,
      CONSTRAINT pk_conn_dataset_id_pipeline_id_tenant_id PRIMARY KEY (tenant_id, dataset_id, connection_id, pipeline_id),
      FOREIGN KEY (tenant_id, pipeline_id, node_id) references pipelines (tenant_id, id, node_id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE INDEX idx_connection_dataset_pipeline_conn_tenant ON connection_dataset_pipeline (tenant_id, connection_id);
