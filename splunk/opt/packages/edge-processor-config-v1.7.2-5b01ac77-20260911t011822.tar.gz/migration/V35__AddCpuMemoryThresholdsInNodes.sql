/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes
    ADD COLUMN cpu_warning_threshold decimal,
    ADD COLUMN mem_warning_threshold decimal;

UPDATE nodes SET cpu_warning_threshold = 80.0 WHERE cpu_warning_threshold IS NULL; -- 80% by default
UPDATE nodes SET mem_warning_threshold = 80.0 WHERE mem_warning_threshold IS NULL; -- 80% by default

ALTER TABLE nodes
    ALTER COLUMN cpu_warning_threshold SET NOT NULL,
    ALTER COLUMN mem_warning_threshold SET NOT NULL;
