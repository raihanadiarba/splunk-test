ALTER TABLE datasets RENAME TO sinks;
ALTER TABLE sinks
  DROP CONSTRAINT pk_datasets_tenant_id_node_id_id,
  ADD CONSTRAINT pk_sinks_tenant_id_node_id_id PRIMARY KEY (tenant_id, node_id, id);