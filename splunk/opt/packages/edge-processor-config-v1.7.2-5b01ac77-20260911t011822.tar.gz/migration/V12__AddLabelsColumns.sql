/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE node RENAME TO nodes;
ALTER TABLE nodes ADD COLUMN labels text[];
ALTER TABLE rulesets ADD COLUMN labels text[];
ALTER TABLE secrets ADD COLUMN labels text[];