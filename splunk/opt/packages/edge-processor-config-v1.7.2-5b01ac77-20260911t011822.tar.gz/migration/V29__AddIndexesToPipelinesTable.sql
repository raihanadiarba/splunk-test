CREATE INDEX pipelines_tenant_pipelineid_nodeid ON pipelines (tenant_id, id, node_id);
CREATE INDEX pipelines_tenant_pipelineid ON pipelines (tenant_id, id);
CREATE INDEX pipelines_tenant_nodeid ON pipelines (tenant_id, node_id);
CREATE INDEX pipelines_tenant ON pipelines (tenant_id);
