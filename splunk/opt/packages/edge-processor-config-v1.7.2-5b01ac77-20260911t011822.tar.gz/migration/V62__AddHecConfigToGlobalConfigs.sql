/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE global_configs ADD COLUMN hec_config jsonb;