/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE pipelines ALTER COLUMN id TYPE VARCHAR(1024);
ALTER TABLE pipelines ALTER COLUMN replaces TYPE VARCHAR(1024);
ALTER TABLE dataset_pipeline ALTER COLUMN pipeline_id TYPE VARCHAR(1024);