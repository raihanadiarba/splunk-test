/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes ADD COLUMN version bigint DEFAULT 0;