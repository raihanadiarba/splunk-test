/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

/*
adding annotations that include additional info about the pipelines
*/

ALTER TABLE pipelines ADD COLUMN annotations text NULL;