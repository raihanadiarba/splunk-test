/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

CREATE TABLE lb_rule
(
    tenant_id           VARCHAR(1024) NOT NULL,
    id                  VARCHAR(36)   NOT NULL,
    name                VARCHAR(1024) NOT NULL,
    description         text,
    spec                VARCHAR(2048) UNIQUE NOT NULL,
    line_breaker        VARCHAR(2048) NOT NULL,
    should_line_merge   BOOLEAN NOT NULL,
    must_break_before   VARCHAR(2048),
    max_events          INT NOT NULL,
    priority            INT,
    context             jsonb,
    created_at          bigint NOT NULL,
    updated_at          bigint NOT NULL,
    created_by          text NOT NULL,
    updated_by          text NOT NULL,
    CONSTRAINT pk_lb_rule_tenant_id_id PRIMARY KEY (tenant_id, id)
);

CREATE INDEX lb_rule_tenant_rule_id ON lb_rule (tenant_id, id);
CREATE INDEX lb_rule_tenant_spec ON lb_rule (tenant_id, spec);
CREATE INDEX lb_rule_tenant ON lb_rule (tenant_id);
