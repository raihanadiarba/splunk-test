/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes ADD COLUMN receivers_config jsonb;