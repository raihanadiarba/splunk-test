/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

CREATE TABLE global_configs
(
    tenant_id                  VARCHAR(36) NOT NULL,
    created                    bigint NOT NULL,
    modified                   bigint NOT NULL,
    created_by                 text NOT NULL,
    modified_by                text NOT NULL,
    telemetry_indexers_dataset text NOT NULL,
    telemetry_index            text NOT NULL,

    CONSTRAINT pk_global_configs_tenant_id PRIMARY KEY (tenant_id)
);
