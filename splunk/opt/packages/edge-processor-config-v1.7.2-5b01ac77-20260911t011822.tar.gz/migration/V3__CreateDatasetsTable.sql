CREATE TABLE datasets
(
    tenant_id   VARCHAR(1024) NOT NULL,
    node_id     VARCHAR(1024) NOT NULL,
    id          VARCHAR(36)   NOT NULL,
    protocol    VARCHAR(1024) NOT NULL,
    properties  jsonb,
    created     bigint,
    modified    bigint,
    CONSTRAINT pk_datasets_tenant_id_node_id_id PRIMARY KEY (tenant_id, node_id, id)
)
