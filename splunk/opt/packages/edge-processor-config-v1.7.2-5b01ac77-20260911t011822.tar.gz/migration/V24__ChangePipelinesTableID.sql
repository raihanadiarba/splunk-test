/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

/*
Search Service use `<requestId without dash>_<unixTimestamp>_<podName suffix>` as job ID
(e.g. `abb61d842cac4a18bd7830e73f985bf8_1646980245982143647_hbgwl`), and the requestId is UUID,
so VARCHAR(36) is not enough for storing job ID (estimated 58 characters)
*/

ALTER TABLE pipelines ALTER COLUMN id TYPE VARCHAR(64);