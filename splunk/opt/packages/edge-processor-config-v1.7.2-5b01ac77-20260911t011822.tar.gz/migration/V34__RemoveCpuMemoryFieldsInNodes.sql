/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE nodes DROP COLUMN cpu_cores;
ALTER TABLE nodes DROP COLUMN memory_mbs;
