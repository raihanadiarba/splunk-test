/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */
UPDATE global_configs
SET hec_config = jsonb_set(
        hec_config,
        '{tokensV2}',
        (
            SELECT jsonb_agg(jsonb_build_object('id', token))
            FROM jsonb_array_elements_text(hec_config->'tokens') AS token
        )
 )
-- tokens can be null so we only process values that are array
WHERE
    -- use case statement rather than AND as null value will trigger error for jsonb_array_length
    CASE WHEN jsonb_typeof(hec_config->'tokens') = 'array'
             THEN jsonb_array_length(hec_config->'tokens') > 0
         ELSE false
    END;
