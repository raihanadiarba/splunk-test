/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE dataset_pipeline ALTER COLUMN dataset_id TYPE text;