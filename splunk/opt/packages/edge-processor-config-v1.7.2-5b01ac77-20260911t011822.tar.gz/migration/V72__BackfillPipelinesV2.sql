INSERT INTO pipelines_v2 (tenant_id, id, version, created, modified, created_by, modified_by,
                          dispatch_table, labels, annotations, replaces)
    (WITH added_row_number AS (SELECT tenant_id,
                                      id,
                                      version,
                                      created,
                                      modified,
                                      created_by,
                                      modified_by,
                                      dispatch_table,
                                      labels,
                                      annotations,
                                      replaces,
                                      ROW_NUMBER() OVER (PARTITION BY (tenant_id, id) ORDER BY version DESC) AS row_number
                               FROM pipelines
                               WHERE (pipelines.tenant_id, pipelines.id) NOT IN (SELECT distinct tenant_id, id from pipelines_v2))
     SELECT tenant_id,
            id,
            version,
            created,
            modified,
            created_by,
            modified_by,
            dispatch_table,
            labels,
            annotations,
            replaces
     FROM added_row_number
     WHERE row_number = 1);
