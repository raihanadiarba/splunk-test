/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */

CREATE TABLE entitlement
(
    tenant_id          VARCHAR(1024) NOT NULL,
    app_client_id      VARCHAR(36) NOT NULL,
    entitlements       jsonb,
    created            BIGINT NOT NULL,
    modified           BIGINT NOT NULL,

    CONSTRAINT pk_entitlement_tenant_id_app_client_id PRIMARY KEY (tenant_id, app_client_id)
)