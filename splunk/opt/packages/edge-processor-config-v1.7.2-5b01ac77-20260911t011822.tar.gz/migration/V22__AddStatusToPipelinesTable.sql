/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE pipelines ADD COLUMN status text DEFAULT 'PENDING' NOT NULL;
