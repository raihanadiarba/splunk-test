/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

CREATE TABLE node_logs
(
    tenant_id   VARCHAR(1024) NOT NULL,
    node_id     VARCHAR(36)   NOT NULL,
    event       VARCHAR(1024) NOT NULL,
    principal   VARCHAR(1024) NOT NULL,
    timestamp   bigint,
    CONSTRAINT  pk_node_logs_tenant_id_id_at PRIMARY KEY (tenant_id, node_id, timestamp)
);

ALTER TABLE nodes ADD COLUMN created_by text;
ALTER TABLE nodes ADD COLUMN modified_by text;
UPDATE nodes SET created_by = 'unknown' WHERE created_by IS NULL;
UPDATE nodes SET modified_by = 'unknown' WHERE modified_by IS NULL;
ALTER TABLE nodes ALTER COLUMN created_by SET NOT NULL;
ALTER TABLE nodes ALTER COLUMN modified_by SET NOT NULL;
