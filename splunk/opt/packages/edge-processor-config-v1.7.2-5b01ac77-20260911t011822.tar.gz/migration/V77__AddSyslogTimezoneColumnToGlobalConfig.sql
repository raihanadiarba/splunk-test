/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

/*
 * The 'syslog_timezone' column will contain IANA identifiers. These are standardized, human-readable names
 * (e.g. 'America/New_York') designed to provide an unambiguous way to represent time zones across the globe.
 * The default value, 'Etc/UTC', is the standard identifier for Coordinated Universal Time (UTC).
 */
ALTER TABLE global_configs
    ADD COLUMN syslog_timezone TEXT DEFAULT 'Etc/UTC';
