CREATE TABLE secrets
(
    tenant_id       VARCHAR(1024) NOT NULL,
    id              VARCHAR(36)   NOT NULL,
    secret_locator  VARCHAR(1024),
    created         bigint,
    deleted         bigint,
    status          VARCHAR(36) NOT NULL,
    CONSTRAINT pk_secrets_tenant_id_id PRIMARY KEY (tenant_id, id)
)
