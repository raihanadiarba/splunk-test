ALTER TABLE nodes DROP COLUMN ruleset_id;
DROP TABLE sources;
DROP TABLE sinks;
DROP TABLE rulesets;
DROP TABLE secrets;