/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */
-- Drop the existing primary key constraint
ALTER TABLE connection_dataset_pipeline DROP CONSTRAINT pk_conn_dataset_id_pipeline_id_tenant_id;

-- Add the new primary key constraint that includes node_id
ALTER TABLE connection_dataset_pipeline ADD CONSTRAINT pk_conn_dataset_id_pipeline_id_tenant_id_node_id
    PRIMARY KEY (tenant_id, dataset_id, connection_id, pipeline_id, node_id);