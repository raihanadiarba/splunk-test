/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE lb_rule DROP CONSTRAINT lb_rule_spec_key;
ALTER TABLE lb_rule ADD CONSTRAINT lb_rule_tenant_id_spec_key UNIQUE (tenant_id, spec);