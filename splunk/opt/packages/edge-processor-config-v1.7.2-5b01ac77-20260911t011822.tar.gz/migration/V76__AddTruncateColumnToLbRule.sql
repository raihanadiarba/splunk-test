/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

ALTER TABLE lb_rule ADD COLUMN truncate INT DEFAULT 10000;