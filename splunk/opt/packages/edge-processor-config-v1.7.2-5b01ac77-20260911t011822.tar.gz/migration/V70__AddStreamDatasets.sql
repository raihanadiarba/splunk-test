/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

with _sources as (
    select tenant_id, id as pipeline_id, node_id, jsonb_array_elements(dispatch_table->'sources') as source from pipelines
    where jsonb_typeof(dispatch_table->'sources') = 'array')

insert into dataset_pipeline
    select tenant_id, source->>'id' as dataset_id, pipeline_id, node_id
    from _sources
    where _sources.source->>'kind'='stream'
    ON CONFLICT DO NOTHING;




