/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE secrets ADD COLUMN secret_type VARCHAR(36);
UPDATE secrets SET secret_type = 'generic' WHERE secret_type IS NULL;
ALTER TABLE secrets ALTER COLUMN secret_type SET NOT NULL;
