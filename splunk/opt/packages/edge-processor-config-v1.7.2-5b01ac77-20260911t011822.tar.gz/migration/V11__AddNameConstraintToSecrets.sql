/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE secrets ADD CONSTRAINT uk_tenant_id_name UNIQUE (tenant_id, name);
