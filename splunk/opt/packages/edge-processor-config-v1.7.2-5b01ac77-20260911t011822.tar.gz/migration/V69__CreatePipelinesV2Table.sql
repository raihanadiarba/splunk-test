/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

CREATE TABLE pipelines_v2
(
    id             VARCHAR(1024) NOT NULL,
    tenant_id      VARCHAR(36)   NOT NULL,
    version        bigint        DEFAULT 0,
    created        bigint        NOT NULL,
    modified       bigint        NOT NULL,
    created_by     text          NOT NULL,
    modified_by    text          NOT NULL,
    dispatch_table jsonb         NOT NULL,
    labels         text[],
    annotations    text          NULL,
    replaces       VARCHAR(1024) DEFAULT NULL,

    CONSTRAINT pk_pipelines_v2_tenant_id_id PRIMARY KEY (tenant_id, id)
);

CREATE INDEX pipelines_v2_tenantid_pipelineid ON pipelines_v2 (tenant_id, id);
CREATE INDEX pipelines_v2_tenantid ON pipelines_v2 (tenant_id);
