/*
 * Copyright (c) 2026 Splunk, Inc. All rights reserved.
 */

UPDATE nodes SET durable_queue_gb=5 WHERE durable_queue_gb IS NULL OR durable_queue_gb=0;
UPDATE nodes SET durable_queue_enabled=true WHERE durable_queue_enabled IS NULL;
