/*
 * Copyright (c) 2023 Splunk, Inc. All rights reserved.
 */

ALTER TABLE global_configs DROP COLUMN telemetry_sink_dataset;
ALTER TABLE global_configs DROP COLUMN telemetry_indexers_dataset;
