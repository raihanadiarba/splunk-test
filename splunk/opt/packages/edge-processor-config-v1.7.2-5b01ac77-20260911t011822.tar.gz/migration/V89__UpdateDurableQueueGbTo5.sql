/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */

UPDATE nodes SET durable_queue_gb=5 WHERE durable_queue_gb = 1;
