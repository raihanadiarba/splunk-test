/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE secrets ADD COLUMN modified bigint;
ALTER TABLE secrets ADD COLUMN name text;
