/*
 * Copyright (c) 2025 Splunk, Inc. All rights reserved.
 */
ALTER TABLE connection_dataset_pipeline
    ALTER COLUMN pipeline_id TYPE VARCHAR(1024),
    ALTER COLUMN pipeline_id SET NOT NULL;
ALTER TABLE connection_dataset_pipeline
    ALTER COLUMN dataset_id TYPE text,
    ALTER COLUMN dataset_id SET NOT NULL;
