/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

CREATE TABLE node
(
    tenant_id   VARCHAR(1024) NOT NULL,
    id          VARCHAR(36)   NOT NULL,
    name        VARCHAR(1024) NOT NULL,
    description VARCHAR(10485760),
    created     bigint,
    modified    bigint,
    CONSTRAINT pk_node_tenant_id_id PRIMARY KEY (tenant_id, id)
)