/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

/*
 * It's been decided that timezone extraction should be supported and consistent across all
 * receivers, not just syslog; therefore, the column is being renamed to simply 'timezone'.
 * Additionally, instead of defaulting to ‘Etc/UTC’, we are providing users with the option
 * to leave the timezone unset. If no value is specified, Splunk will automatically set it to
 * the indexer’s timezone.
 */
ALTER TABLE global_configs
    RENAME COLUMN syslog_timezone TO timezone;

ALTER TABLE global_configs
    ALTER COLUMN timezone DROP DEFAULT;
