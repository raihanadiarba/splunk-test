/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE global_configs ADD COLUMN context jsonb;