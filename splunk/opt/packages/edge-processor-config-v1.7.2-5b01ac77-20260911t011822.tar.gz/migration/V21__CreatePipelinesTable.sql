/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

CREATE TABLE pipelines
(
    tenant_id   VARCHAR(36)   NOT NULL,
    id          VARCHAR(36)   NOT NULL,
    node_id     VARCHAR(36)   NOT NULL,
    created     bigint NOT NULL,
    modified    bigint NOT NULL,
    created_by text NOT NULL,
    modified_by text NOT NULL,
    dispatch_table jsonb NOT NULL,

    CONSTRAINT pk_pipelines_tenant_id_node_id_id PRIMARY KEY (tenant_id, node_id, id)
);
