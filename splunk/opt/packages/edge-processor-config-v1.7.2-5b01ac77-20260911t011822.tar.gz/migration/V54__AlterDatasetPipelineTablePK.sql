/*
 * Copyright (c) 2022 Splunk, Inc. All rights reserved.
 */

ALTER TABLE dataset_pipeline DROP CONSTRAINT pk_dataset_id_pipeline_id_tenant_id;
ALTER TABLE dataset_pipeline ADD CONSTRAINT pk_tenant_id_dataset_id_pipeline_id_tenant_id_node_id PRIMARY KEY (tenant_id, dataset_id, pipeline_id, node_id);