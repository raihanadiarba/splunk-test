/*
 * Copyright (c) 2024 Splunk, Inc. All rights reserved.
 */

CREATE TABLE command_event
(
    command               int NOT NULL,
    tenant_id             VARCHAR(1024) NOT NULL,
    node_id               VARCHAR(36) NOT NULL,
    pipeline_id           VARCHAR(255),
    lbrule_id             VARCHAR(255),
    pipeline_version      BIGINT,
    lb_rule_version       BIGINT,
    global_config_version BIGINT,
    node_version          BIGINT,
    created_at            BIGINT NOT NULL,
    trace_id              VARCHAR(255),
    parent_id             VARCHAR(255),
    retries               INTEGER DEFAULT 0 NOT NULL,
    message_id            VARCHAR(36) NOT NULL,
    CONSTRAINT pk_command_event PRIMARY KEY (tenant_id, node_id, created_at, message_id)
)