/*
 * Copyright (c) 2021 Splunk, Inc. All rights reserved.
 */

ALTER TABLE sinks ADD COLUMN secret_id VARCHAR(36);
ALTER TABLE sources ADD COLUMN secret_id VARCHAR(36);