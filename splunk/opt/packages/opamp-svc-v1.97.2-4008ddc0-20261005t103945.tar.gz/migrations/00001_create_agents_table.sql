-- +goose Up
-- +goose StatementBegin

-- Table Definitions --

CREATE TABLE IF NOT EXISTS agents
(
    tenant             text             NOT NULL,
    group_class        text             NOT NULL,
    agent_id           varchar(36)      NOT NULL,
    token_updated      bigint,
    config_hash        text,
    package_hash       text,
    packages_running   jsonb,
    node_info          jsonb,
    agent_description  jsonb,

    PRIMARY KEY ( tenant, agent_id )
);

CREATE TABLE IF NOT EXISTS metrics
(
    tenant             text             NOT NULL,
    group_class        text             NOT NULL,
    agent_id           varchar(36)      NOT NULL,
    metrics            jsonb,

    PRIMARY KEY ( tenant, agent_id ),
    CONSTRAINT fk_agents FOREIGN KEY ( tenant, agent_id )
    REFERENCES agents( tenant, agent_id )
    ON DELETE CASCADE
);

-- Indices --

CREATE INDEX IF NOT EXISTS idx_agent_group
    ON agents (tenant, group_class);

CREATE INDEX IF NOT EXISTS idx_agent_metrics
    ON metrics (tenant, agent_id);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS metrics;
DROP TABLE IF EXISTS agents;
-- +goose StatementEnd