-- add group_class and is_default columns to package_plan table.
-- Set default plans for edge and splunksup plans. Set group_class based on naming convention of edge and splunksup package-plans.

-- +goose Up
-- +goose StatementBegin
ALTER TABLE package_plan
    ADD COLUMN IF NOT EXISTS group_class text DEFAULT '' NOT NULL,
    ADD COLUMN IF NOT EXISTS is_default boolean DEFAULT false NOT NULL;

-- Set default plans for edge and splunksup plans
UPDATE package_plan
    SET is_default = true WHERE name IN ('edge__system_all', 'splunksup__system_all');

-- Set group_class based on the first default_target_rules entry's groupClass
UPDATE package_plan
SET group_class = default_target_rules->0->>'groupClass'
WHERE default_target_rules->0->>'groupClass' IS NOT NULL;

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE package_plan
    DROP COLUMN IF EXISTS is_default,
    DROP COLUMN IF EXISTS group_class;
-- +goose StatementEnd
