-- +goose Up
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS service_principal text;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents
    DROP COLUMN IF EXISTS service_principal;
-- +goose StatementEnd
