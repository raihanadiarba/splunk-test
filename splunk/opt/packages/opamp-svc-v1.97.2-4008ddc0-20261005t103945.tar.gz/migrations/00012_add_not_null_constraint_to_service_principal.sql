-- +goose Up
-- +goose StatementBegin
-- Existing data -- 
UPDATE agents SET service_principal = '' WHERE service_principal IS NULL;

-- Table Modifications --
ALTER TABLE agents
ALTER COLUMN service_principal SET DEFAULT '',
ALTER COLUMN service_principal SET NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE agents 
ALTER COLUMN service_principal DROP NOT NULL,
ALTER COLUMN service_principal DROP DEFAULT;

-- Existing data -- 
UPDATE agents SET service_principal = NULL WHERE service_principal = '';
-- +goose StatementEnd
