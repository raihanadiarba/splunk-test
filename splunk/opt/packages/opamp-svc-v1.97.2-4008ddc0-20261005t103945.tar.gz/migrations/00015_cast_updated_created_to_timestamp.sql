-- +goose Up
-- +goose StatementBegin

-- Table Modifications --
ALTER TABLE package_plan
ALTER COLUMN updated DROP DEFAULT,
ALTER COLUMN updated TYPE TIMESTAMP WITH TIME ZONE USING to_timestamp(updated),
ALTER COLUMN updated SET DEFAULT now(),
ALTER COLUMN created TYPE TIMESTAMP WITH TIME ZONE USING to_timestamp(created),
ALTER COLUMN created SET DEFAULT now();
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE package_plan
ALTER COLUMN updated DROP DEFAULT,
ALTER COLUMN updated TYPE INT USING extract(epoch from updated),
ALTER COLUMN updated SET DEFAULT 0,
ALTER COLUMN created DROP DEFAULT,
ALTER COLUMN created TYPE INT USING extract(epoch from created);
-- +goose StatementEnd
