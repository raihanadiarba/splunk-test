-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents DROP COLUMN IF EXISTS is_orchestrated;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents ADD COLUMN IF NOT EXISTS is_orchestrated boolean DEFAULT false NOT NULL;
-- +goose StatementEnd
