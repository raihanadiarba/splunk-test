package migrations

import (
	_ "embed"
	"fmt"
	"os"
	"path/filepath"
)

//go:embed 00001_create_agents_table.sql
var CreateAgentsTable []byte

//go:embed 00002_create_config_table.sql
var CreateConfigTable []byte

//go:embed 00003_create_packages_table.sql
var CreatePackagesTable []byte

//go:embed 00004_create_package_plan_table.sql
var CreatePackagePlanTable []byte

//go:embed 00005_add_columns_to_agents_table.sql
var AddColumnsToAgentsTable []byte

//go:embed 00006_add_heartbeat_and_os_to_agents_table.sql
var AddHeartbeatAndOsToAgentsTable []byte

//go:embed 00007_add_service_principal_to_agents_table.sql
var AddServicePrincipalToAgentsTable []byte

//go:embed 00008_drop_packages_table.sql
var DropPackagesTable []byte

//go:embed 00009_add_rollback_columns.sql
var AddRollbackColumns []byte

//go:embed 00010_make_composite_indexes_agents_table.sql
var MakeCompositeIndexesAgentsTable []byte

//go:embed 00011_cast_agent_id_to_text.sql
var CastAgentIdToText []byte

//go:embed 00012_add_not_null_constraint_to_service_principal.sql
var AddNotNullConstraintToServicePrincipal []byte

//go:embed 00013_cast_capabilities_to_numeric.sql
var CastCapabilitiesToNumeric []byte

//go:embed 00014_add_not_null_constraint_to_updated.sql
var AddNotNullConstraintToUpdated []byte

//go:embed 00015_cast_updated_created_to_timestamp.sql
var CastUpdatedCreatedToTimestamp []byte

//go:embed 00016_add_effective_config_column_to_agents.sql
var AddEffectiveConfigColumnToAgents []byte

//go:embed 00017_add_remote_config_status_column_to_agents.sql
var AddRemoteConfigStatusColumnToAgents []byte

//go:embed 00018_split_agent_desired_packages_tenant_columns.sql
var SplitAgentDesiredPackagesTenantColumns []byte

//go:embed 00019_add_next_check_time.sql
var AddNextCheckTimeColumn []byte

//go:embed 00020_add_sequence_num_column_to_agents.sql
var AddSequenceNumColumnToAgents []byte

//go:embed 00021_add_is_orchestrated_column_to_agents.sql
var AddIsOrchestratedColumnToAgents []byte

//go:embed 00022_add_expected_heartbeat_time_index.sql
var AddExpectedHeartbeatTimeIndex []byte

//go:embed 00023_add_deployment_type_and_is_ephemeral_columns_to_agents.sql
var AddDeploymentTypeAndIsEphemeralColumnsToAgents []byte

//go:embed 00024_remove_is_orchestrated_column_from_agents.sql
var RemoveIsOrchestratedColumnFromAgents []byte

//go:embed 00025_add_instance_name_column_to_agents.sql
var AddInstanceNameColumnToAgents []byte

//go:embed 00026_add_groupClass_isDefault_to_package_plan.sql
var AddGroupClassIsDefaultToPackagePlan []byte

//go:embed 00027_backfill_agent_data_using_edge_hostname.sql
var BackfillAgentDataUsingEdgeHostname []byte

//go:embed 00028_add_sidecar_to_deployment_type_enum.sql
var AddSidecarToDeploymentTypeEnum []byte

//go:embed 00029_rename_agent_service_principal_column.sql
var RenameAgentServicePrincipalColumn []byte

//go:embed 00030_add_pre_update_state_to_agents.sql
var AddPreUpdateState []byte

//go:embed 00031_create_remote_config_set_tables.sql
var CreateRemoteConfigSetTables []byte

//go:embed 00032_add_agent_environment.sql
var AddAgentEnvironment []byte

var AllMigrations = map[string][]byte{
	"00001_create_agents_table.sql":                                    CreateAgentsTable,
	"00002_create_config_table.sql":                                    CreateConfigTable,
	"00003_create_packages_table.sql":                                  CreatePackagesTable,
	"00004_create_package_plan_table.sql":                              CreatePackagePlanTable,
	"00005_add_columns_to_agents_table.sql":                            AddColumnsToAgentsTable,
	"00006_add_heartbeat_and_os_to_agents_table.sql":                   AddHeartbeatAndOsToAgentsTable,
	"00007_add_service_principal_to_agents_table.sql":                  AddServicePrincipalToAgentsTable,
	"00008_drop_packages_table.sql":                                    DropPackagesTable,
	"00009_add_rollback_columns.sql":                                   AddRollbackColumns,
	"00010_make_composite_indexes_agents_table.sql":                    MakeCompositeIndexesAgentsTable,
	"00011_cast_agent_id_to_text.sql":                                  CastAgentIdToText,
	"00012_add_not_null_constraint_to_service_principal.sql":           AddNotNullConstraintToServicePrincipal,
	"00013_cast_capabilities_to_numeric.sql":                           CastCapabilitiesToNumeric,
	"00014_add_not_null_constraint_to_updated.sql":                     AddNotNullConstraintToUpdated,
	"00015_cast_updated_created_to_timestamp.sql":                      CastUpdatedCreatedToTimestamp,
	"00016_add_effective_config_column_to_agents.sql":                  AddEffectiveConfigColumnToAgents,
	"00017_add_remote_config_status_column_to_agents.sql":              AddRemoteConfigStatusColumnToAgents,
	"00018_split_agent_desired_packages_tenant_columns.sql":            SplitAgentDesiredPackagesTenantColumns,
	"00019_add_next_check_time.sql":                                    AddNextCheckTimeColumn,
	"00020_add_sequence_num_column_to_agents.sql":                      AddSequenceNumColumnToAgents,
	"00021_add_is_orchestrated_column_to_agents.sql":                   AddIsOrchestratedColumnToAgents,
	"00022_add_expected_heartbeat_time_index.sql":                      AddExpectedHeartbeatTimeIndex,
	"00023_add_deployment_type_and_is_ephemeral_columns_to_agents.sql": AddDeploymentTypeAndIsEphemeralColumnsToAgents,
	"00024_remove_is_orchestrated_column_from_agents.sql":              RemoveIsOrchestratedColumnFromAgents,
	"00025_add_instance_name_column_to_agents.sql":                     AddInstanceNameColumnToAgents,
	"00026_add_groupClass_isDefault_to_package_plan.sql":               AddGroupClassIsDefaultToPackagePlan,
	"00027_backfill_agent_data_using_edge_hostname.sql":                BackfillAgentDataUsingEdgeHostname,
	"00028_add_sidecar_to_deployment_type_enum.sql":                    AddSidecarToDeploymentTypeEnum,
	"00029_rename_agent_service_principal_column.sql":                  RenameAgentServicePrincipalColumn,
	"00030_add_pre_update_state_to_agents.sql":                         AddPreUpdateState,
	"00031_create_remote_config_set_tables.sql":                        CreateRemoteConfigSetTables,
	"00032_add_agent_environment.sql":                                  AddAgentEnvironment,
}

func SaveAllMigrations(dir string) error {
	for name, migration := range AllMigrations {
		err := os.WriteFile(filepath.Join(dir, name), migration, 0o644)
		if err != nil {
			return fmt.Errorf("failed to write migration %s: %w", name, err)
		}
	}
	return nil
}
