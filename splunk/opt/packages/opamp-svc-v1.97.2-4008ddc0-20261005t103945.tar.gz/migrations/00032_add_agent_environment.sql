-- Persist deployment.environment.name as a first-class filter column.
-- This avoids JSONB scans over agent_description for list/count/filter-values
-- queries while keeping future arbitrary attributes out of the agents table.

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents
ADD COLUMN IF NOT EXISTS environment text;

CREATE INDEX IF NOT EXISTS idx_agents_environment_v2
ON agents (tenant, group_class, environment, agent_id)
WHERE environment IS NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP INDEX IF EXISTS idx_agents_environment_v2;

ALTER TABLE agents
DROP COLUMN IF EXISTS environment;
-- +goose StatementEnd
