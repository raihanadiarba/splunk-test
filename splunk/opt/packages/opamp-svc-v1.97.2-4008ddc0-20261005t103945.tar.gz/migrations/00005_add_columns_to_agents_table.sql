-- +goose Up
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS ip INET,
    ADD COLUMN IF NOT EXISTS name text,
    ADD COLUMN IF NOT EXISTS hostname text,
    ADD COLUMN IF NOT EXISTS namespace text,
    ADD COLUMN IF NOT EXISTS version text;

-- Copy hostname to new column --
UPDATE agents
SET hostname = node_info->>'HostName' WHERE node_info ? 'HostName' AND node_info ->> 'HostName' <> '';

-- Remove duplicated data --
UPDATE agents
SET node_info = node_info - 'HostName' WHERE 1=1;

-- Indices --
CREATE INDEX IF NOT EXISTS idx_agents_ip ON agents (ip);
CREATE INDEX IF NOT EXISTS idx_agents_name ON agents (name);
CREATE INDEX IF NOT EXISTS idx_agents_hostname ON agents (hostname);
CREATE INDEX IF NOT EXISTS idx_agents_namespace ON agents (namespace);
CREATE INDEX IF NOT EXISTS idx_agents_version ON agents (version);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents
    DROP COLUMN IF EXISTS ip,
    DROP COLUMN IF EXISTS name,
    DROP COLUMN IF EXISTS hostname,
    DROP COLUMN IF EXISTS namespace,
    DROP COLUMN IF EXISTS version;
-- +goose StatementEnd