-- +goose Up
-- +goose StatementBegin
DROP TABLE IF EXISTS packages;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

CREATE TABLE IF NOT EXISTS packages (
                                        group_class     text        NOT NULL,
                                        group_id        text        NOT NULL,
                                        packages        jsonb       NOT NULL,
                                        hash            text        NOT NULL,
                                        PRIMARY KEY ( group_class, group_id )
    );
-- +goose StatementEnd