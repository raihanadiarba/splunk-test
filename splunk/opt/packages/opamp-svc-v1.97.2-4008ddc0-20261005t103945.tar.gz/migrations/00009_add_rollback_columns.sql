-- Add columns to existing tables, for supporting package rollback on failed deploys

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents
ADD COLUMN IF NOT EXISTS last_successful_packages jsonb;

ALTER TABLE agent_desired_packages
ADD COLUMN IF NOT EXISTS pkg_deploy_hashes jsonb;

ALTER TABLE package_plan_lock
ADD COLUMN IF NOT EXISTS deploy_start_time bigint DEFAULT 0 NOT NULL,
ADD COLUMN IF NOT EXISTS failed boolean DEFAULT false NOT NULL;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents
DROP COLUMN IF EXISTS last_successful_packages;

ALTER TABLE agent_desired_packages
DROP COLUMN IF EXISTS pkg_deploy_hashes;

ALTER TABLE package_plan_lock
DROP COLUMN IF EXISTS deploy_start_time,
DROP COLUMN IF EXISTS failed;
-- +goose StatementEnd
