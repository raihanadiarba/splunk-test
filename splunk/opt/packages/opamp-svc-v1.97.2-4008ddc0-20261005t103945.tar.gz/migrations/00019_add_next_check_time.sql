-- add next_check_time column to package_plan_lock table to prevent the same row from being checked again
-- immediately after it was processed

-- +goose Up
-- +goose StatementBegin
ALTER TABLE package_plan_lock
ADD COLUMN IF NOT EXISTS next_check_time bigint DEFAULT 0 NOT NULL;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE package_plan_lock
DROP COLUMN IF EXISTS next_check_time;
-- +goose StatementEnd
