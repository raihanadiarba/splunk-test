-- +goose Up
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS system_description text,
    ADD COLUMN IF NOT EXISTS system text,
    ADD COLUMN IF NOT EXISTS cpu_architecture text,
    ADD COLUMN IF NOT EXISTS capabilities int NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS last_heartbeat_time timestamp with time zone,
    ADD COLUMN IF NOT EXISTS expected_heartbeat_time timestamp with time zone,
    ADD COLUMN IF NOT EXISTS heartbeat_interval bigint NOT NULL DEFAULT 0;

-- Indices --
CREATE INDEX IF NOT EXISTS idx_agents_system_description ON agents (system_description);
CREATE INDEX IF NOT EXISTS idx_agents_system ON agents (system);
CREATE INDEX IF NOT EXISTS idx_agents_cpu_architecture ON agents (cpu_architecture);
CREATE INDEX IF NOT EXISTS idx_agents_capabilities ON agents (capabilities);
CREATE INDEX IF NOT EXISTS idx_agents_last_heartbeat_time ON agents (last_heartbeat_time);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents
    DROP COLUMN IF EXISTS system_description,
    DROP COLUMN IF EXISTS system,
    DROP COLUMN IF EXISTS cpu_architecture,
    DROP COLUMN IF EXISTS capabilities,
    DROP COLUMN IF EXISTS last_heartbeat_time,
    DROP COLUMN IF EXISTS expected_heartbeat_time,
    DROP COLUMN IF EXISTS heartbeat_interval;
-- +goose StatementEnd
