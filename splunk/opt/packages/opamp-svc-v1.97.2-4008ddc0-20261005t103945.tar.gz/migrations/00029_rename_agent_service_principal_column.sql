-- rename service_principal column to auth_id column to be more generic for both SCS servicePrincipalId and CMP clientId

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents RENAME COLUMN service_principal TO auth_id;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents RENAME COLUMN auth_id TO service_principal;
-- +goose StatementEnd
