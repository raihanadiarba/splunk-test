-- +goose Up
-- +goose StatementBegin

-- Table Definitions --

CREATE TABLE IF NOT EXISTS remote_config_sets (
    id uuid                         NOT NULL,
    tenant text                     NOT NULL,
    group_class text                NOT NULL,
    name text                       NOT NULL,
    description text                NOT NULL,
    hash text                       NOT NULL,
    created timestamp with time zone NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant, id),
    CONSTRAINT remote_config_sets_tenant_group_name_unique UNIQUE (tenant, group_class, name)
);

CREATE TABLE IF NOT EXISTS remote_config_set_files (
    id uuid                         NOT NULL,
    tenant text                     NOT NULL,
    config_set_id uuid              NOT NULL,
    name text                       NOT NULL,
    content_type text               NOT NULL,
    body bytea                      NOT NULL,
    hash text                       NOT NULL,
    created timestamp with time zone NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant, id),
    CONSTRAINT remote_config_set_files_set_name_unique UNIQUE (tenant, config_set_id, name),
    CONSTRAINT fk_remote_config_set_files_config_set FOREIGN KEY (tenant, config_set_id)
    REFERENCES remote_config_sets(tenant, id)
    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_remote_config_assignments (
    tenant text                     NOT NULL,
    agent_id text                   NOT NULL,
    group_class text                NOT NULL,
    config_set_id uuid              NOT NULL,
    created timestamp with time zone NOT NULL DEFAULT now(),
    updated timestamp with time zone NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant, agent_id),
    CONSTRAINT fk_agent_remote_config_assignments_agents FOREIGN KEY (tenant, agent_id)
    REFERENCES agents(tenant, agent_id)
    ON DELETE CASCADE,
    CONSTRAINT fk_agent_remote_config_assignments_config_set FOREIGN KEY (tenant, config_set_id)
    REFERENCES remote_config_sets(tenant, id)
    -- Prevent deleting a Config Set while agents are still assigned to it.
    ON DELETE RESTRICT
);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

DROP TABLE IF EXISTS agent_remote_config_assignments;
DROP TABLE IF EXISTS remote_config_set_files;
DROP TABLE IF EXISTS remote_config_sets;

-- +goose StatementEnd
