-- Add columns to existing tables, for supporting package rollback on failed deploys

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS sequence_num BIGINT DEFAULT 0;

-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents
    DROP COLUMN IF EXISTS sequence_num;
-- +goose StatementEnd
