-- add index on expected_heartbeat_time to optimize queries when purging stale agents

-- +goose Up
-- +goose StatementBegin
CREATE INDEX IF NOT EXISTS idx_agents_expected_heartbeat_time ON agents (expected_heartbeat_time);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP INDEX IF EXISTS idx_agents_expected_heartbeat_time;
-- +goose StatementEnd
