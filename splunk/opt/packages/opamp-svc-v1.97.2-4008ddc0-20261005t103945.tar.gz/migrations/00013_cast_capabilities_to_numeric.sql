-- +goose Up
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE agents
ALTER COLUMN capabilities TYPE NUMERIC(20, 0);
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- Existing data -- 
UPDATE agents SET capabilities = 0 WHERE capabilities > 2147483647;
UPDATE agents SET capabilities = 0 WHERE capabilities < -2147483648;

-- Table Modifications --
ALTER TABLE agents
ALTER COLUMN capabilities TYPE INT;
-- +goose StatementEnd
