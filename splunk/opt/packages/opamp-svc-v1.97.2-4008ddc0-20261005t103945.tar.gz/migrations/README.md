# Opamp-service Data Definition Language(DDL)

This directory is used to store sql scripts to initialize database needed
for opamp-service
