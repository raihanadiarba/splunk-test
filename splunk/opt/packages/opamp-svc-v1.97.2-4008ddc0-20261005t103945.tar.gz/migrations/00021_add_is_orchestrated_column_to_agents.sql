-- add column to track whether an agent is a standalone instance or part of an orchestrated cluster (e.g., k8s, ecs)

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents ADD COLUMN IF NOT EXISTS is_orchestrated boolean DEFAULT false NOT NULL;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents DROP COLUMN IF EXISTS is_orchestrated;
-- +goose StatementEnd