-- +goose Up
-- +goose StatementBegin

-- Indices --

-- create composite indexes
-- an additional index for agent_id within a group_class
CREATE INDEX IF NOT EXISTS idx_agents_agent_id_v2 ON agents (tenant, group_class, agent_id);
-- from 00005_add_columns_to_agents_table.sql
CREATE INDEX IF NOT EXISTS idx_agents_ip_v2 ON agents (tenant, group_class, ip, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_name_v2 ON agents (tenant, group_class, name, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_hostname_v2 ON agents (tenant, group_class, hostname, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_namespace_v2 ON agents (tenant, group_class, namespace, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_version_v2 ON agents (tenant, group_class, version, agent_id);
-- from 00006_add_heartbeat_and_os_to_agents_table.sql
CREATE INDEX IF NOT EXISTS idx_agents_system_description_v2 ON agents (tenant, group_class, system_description, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_system_v2 ON agents (tenant, group_class, system, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_cpu_architecture_v2 ON agents (tenant, group_class, cpu_architecture, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_capabilities_v2 ON agents (tenant, group_class, capabilities, agent_id);
CREATE INDEX IF NOT EXISTS idx_agents_last_heartbeat_time_v2 ON agents (tenant, group_class, last_heartbeat_time);              -- agent_id is not part of index here, as this is a timestamp so collision chance is low
-- add additional index for the expected_heartbeat_time column
CREATE INDEX IF NOT EXISTS idx_agents_expected_heartbeat_time_v2 ON agents (tenant, group_class, expected_heartbeat_time);      -- agent_id is not part of index here, as this is a timestamp so collision chance is low

-- drop indexes as they are obsolete now
-- from 00001_create_agents_table.sql (this index was replaced by idx_agents_agent_id_v2)
DROP INDEX IF EXISTS idx_agent_group;
-- from 00005_add_columns_to_agents_table.sql
DROP INDEX IF EXISTS idx_agents_ip;
DROP INDEX IF EXISTS idx_agents_name;
DROP INDEX IF EXISTS idx_agents_hostname;   
DROP INDEX IF EXISTS idx_agents_namespace;
DROP INDEX IF EXISTS idx_agents_version;
-- from 00006_add_heartbeat_and_os_to_agents_table.sql
DROP INDEX IF EXISTS idx_agents_system_description;
DROP INDEX IF EXISTS idx_agents_system;
DROP INDEX IF EXISTS idx_agents_cpu_architecture;
DROP INDEX IF EXISTS idx_agents_capabilities;
DROP INDEX IF EXISTS idx_agents_last_heartbeat_time;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin

-- restore old indexes
-- from 00001_create_agents_table.sql
CREATE INDEX IF NOT EXISTS idx_agent_group ON agents (tenant, group_class);
-- from 00006_add_heartbeat_and_os_to_agents_table.sql
CREATE INDEX IF NOT EXISTS idx_agents_ip ON agents (ip);
CREATE INDEX IF NOT EXISTS idx_agents_name ON agents (name);
CREATE INDEX IF NOT EXISTS idx_agents_hostname ON agents (hostname);
CREATE INDEX IF NOT EXISTS idx_agents_namespace ON agents (namespace);
CREATE INDEX IF NOT EXISTS idx_agents_version ON agents (version);
-- from 00005_add_columns_to_agents_table.sql
CREATE INDEX IF NOT EXISTS idx_agents_system_description ON agents (system_description);
CREATE INDEX IF NOT EXISTS idx_agents_system ON agents (system);
CREATE INDEX IF NOT EXISTS idx_agents_cpu_architecture ON agents (cpu_architecture);
CREATE INDEX IF NOT EXISTS idx_agents_capabilities ON agents (capabilities);
CREATE INDEX IF NOT EXISTS idx_agents_last_heartbeat_time ON agents (last_heartbeat_time);

-- drop composite indexes
-- an additional index for agent_id within a group_class
DROP INDEX IF EXISTS idx_agents_agent_id_v2;
-- from 00005_add_columns_to_agents_table.sql
DROP INDEX IF EXISTS idx_agents_ip_v2;
DROP INDEX IF EXISTS idx_agents_name_v2;
DROP INDEX IF EXISTS idx_agents_hostname_v2;
DROP INDEX IF EXISTS idx_agents_namespace_v2;
DROP INDEX IF EXISTS idx_agents_version_v2;
-- from 00006_add_heartbeat_and_os_to_agents_table.sql
DROP INDEX IF EXISTS idx_agents_system_description_v2;
DROP INDEX IF EXISTS idx_agents_system_v2;
DROP INDEX IF EXISTS idx_agents_cpu_architecture_v2;
DROP INDEX IF EXISTS idx_agents_capabilities_v2;
DROP INDEX IF EXISTS idx_agents_last_heartbeat_time_v2;
-- add additional index for the expected_heartbeat_time column
DROP INDEX IF EXISTS idx_agents_expected_heartbeat_time_v2;
-- +goose StatementEnd