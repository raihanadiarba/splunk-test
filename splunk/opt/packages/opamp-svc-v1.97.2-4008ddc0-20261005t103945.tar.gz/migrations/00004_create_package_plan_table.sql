-- +goose Up
-- +goose StatementBegin

-- Table Definitions --

CREATE TABLE IF NOT EXISTS package_plan (
    id text                         NOT NULL,
    tenant text                     NOT NULL,
    name text                       NOT NULL,
    default_target_rules jsonb      NOT NULL,
    excluded_target_rules jsonb     NOT NULL,
    created_by text                 NOT NULL,
    created int                     NOT NULL,
    updated_by text,
    updated int,
    version int                     NOT NULL,
    rollout_stages jsonb            NOT NULL,
    PRIMARY KEY (id, tenant)
);

CREATE TABLE IF NOT EXISTS package_plan_lock (
    id text                         NOT NULL,
    tenant text                     NOT NULL,
    version int                     NOT NULL,
    sequence int                    NOT NULL,
    done boolean                    NOT NULL,
    PRIMARY KEY (id, tenant)
);

CREATE TABLE IF NOT EXISTS platform_package_plan (
    id text                         NOT NULL,
    tenant text                     NOT NULL,
    platform text                   NOT NULL,
    hash text                       NOT NULL,
    packages jsonb                  NOT NULL,
    PRIMARY KEY (id, tenant, platform),
    CONSTRAINT fk_package_plans FOREIGN KEY ( id, tenant )
    REFERENCES package_plan(id, tenant)
    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_desired_packages (
    agent_id varchar(36)            NOT NULL,
    tenant text                     NOT NULL,
    id text                         NOT NULL,
    packages jsonb                  NOT NULL,
    hash text                       NOT NULL,
    PRIMARY KEY (tenant, agent_id),
    CONSTRAINT fk_agents FOREIGN KEY (tenant, agent_id)
    REFERENCES agents(tenant, agent_id)
    ON DELETE CASCADE,
    CONSTRAINT fk_package_plans FOREIGN KEY (id, tenant)
    REFERENCES package_plan(id, tenant)
    ON DELETE CASCADE
);

-- Indices --

CREATE INDEX IF NOT EXISTS idx_package_plan_tenant_name
    ON package_plan (id, tenant);

CREATE INDEX IF NOT EXISTS idx_package_plan_lock_id_tenant
    ON package_plan_lock (id, tenant);

CREATE INDEX IF NOT EXISTS idx_platform_package_plan_tenant_platform
    ON platform_package_plan (tenant, platform);

CREATE INDEX IF NOT EXISTS idx_agent_desired_packages_tenant_agent_id
    ON agent_desired_packages (tenant, agent_id);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS agent_desired_packages;
DROP TABLE IF EXISTS platform_package_plan;
DROP TABLE IF EXISTS package_plan_lock;
DROP TABLE IF EXISTS package_plan;
-- +goose StatementEnd
