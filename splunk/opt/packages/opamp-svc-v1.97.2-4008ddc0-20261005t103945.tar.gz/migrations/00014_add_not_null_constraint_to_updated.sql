-- +goose Up
-- +goose StatementBegin
-- Existing data --
UPDATE package_plan SET updated = 0 WHERE updated IS NULL;
UPDATE package_plan SET updated_by = '' WHERE updated_by IS NULL;

-- Table Modifications --
ALTER TABLE package_plan
ALTER COLUMN updated SET DEFAULT 0,
ALTER COLUMN updated SET NOT NULL,
ALTER COLUMN updated_by SET DEFAULT '',
ALTER COLUMN updated_by SET NOT NULL;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE package_plan
ALTER COLUMN updated DROP NOT NULL,
ALTER COLUMN updated DROP DEFAULT,
ALTER COLUMN updated_by DROP NOT NULL,
ALTER COLUMN updated_by DROP DEFAULT;

-- Existing data -- 
UPDATE package_plan SET updated = NULL WHERE updated = 0;
UPDATE package_plan SET updated_by = NULL WHERE updated_by = '';
-- +goose StatementEnd
