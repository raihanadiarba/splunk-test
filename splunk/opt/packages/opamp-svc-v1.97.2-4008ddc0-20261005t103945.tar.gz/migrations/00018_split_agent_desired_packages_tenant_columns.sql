-- +goose Up
-- +goose StatementBegin

-- Split tenant column in agent_desired_packages table into agent_tenant and package_plan_tenant
-- agent_desired_packages currently has two foreign key constraints:
--      (agent_id, tenant) -> agents(agent_id, tenant)
--      (id, tenant) -> package_plan(id, tenant)
-- For a system package plan, the agents constraint requires {agent_id=agent_id, tenant=tenant}
-- and the package_plan constraint requires {id=plan_id, tenant=system} which causes a conflict
-- Splitting the tenant column will provide visibility on if a system package plan was used and
-- maintain visibility on which tenant the agent belongs to

ALTER TABLE agent_desired_packages
    DROP CONSTRAINT IF EXISTS fk_package_plans;

ALTER TABLE agent_desired_packages
    DROP CONSTRAINT IF EXISTS fk_agents;

ALTER TABLE agent_desired_packages
    ADD COLUMN IF NOT EXISTS package_plan_tenant text;

ALTER TABLE agent_desired_packages
    RENAME COLUMN tenant TO agent_tenant;

ALTER TABLE agent_desired_packages
    ADD CONSTRAINT fk_package_plans
    FOREIGN KEY (id, package_plan_tenant)
    REFERENCES package_plan(id, tenant)
    ON DELETE CASCADE;

ALTER TABLE agent_desired_packages
    ADD CONSTRAINT fk_agents
    FOREIGN KEY (agent_tenant, agent_id)
    REFERENCES agents(tenant, agent_id)
    ON DELETE CASCADE;

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

ALTER TABLE agent_desired_packages
    DROP CONSTRAINT IF EXISTS fk_agents;

ALTER TABLE agent_desired_packages
    DROP CONSTRAINT IF EXISTS fk_package_plans;

ALTER TABLE agent_desired_packages
    RENAME COLUMN agent_tenant TO tenant;

ALTER TABLE agent_desired_packages
    DROP COLUMN IF EXISTS package_plan_tenant;

ALTER TABLE agent_desired_packages
    ADD CONSTRAINT fk_agents
    FOREIGN KEY (tenant, agent_id)
    REFERENCES agents(tenant, agent_id)
    ON DELETE CASCADE;

ALTER TABLE agent_desired_packages
    ADD CONSTRAINT fk_package_plans
    FOREIGN KEY (id, tenant)
    REFERENCES package_plan(id, tenant)
    ON DELETE CASCADE;

-- +goose StatementEnd