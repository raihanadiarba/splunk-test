-- +goose Up
-- +goose StatementBegin

-- Table Definitions --

ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS effective_config JSONB;

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

ALTER TABLE agents
    DROP COLUMN IF EXISTS effective_config;
    
-- +goose StatementEnd
