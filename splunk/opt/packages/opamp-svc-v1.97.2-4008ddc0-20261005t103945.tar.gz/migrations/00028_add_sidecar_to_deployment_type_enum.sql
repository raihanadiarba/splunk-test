-- add 'sidecar' to the agent_deployment_type enum.
--  → sidecar: indicates the agent is deployed as a sidecar container.

-- +goose Up
-- +goose StatementBegin
ALTER TYPE agent_deployment_type ADD VALUE IF NOT EXISTS 'sidecar';
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
-- Note: PostgreSQL does not support removing enum values directly.
-- To remove 'sidecar', you would need to:
-- 1. Create a new enum without 'sidecar'
-- 2. Alter the column to use the new enum
-- 3. Drop the old enum
-- This is a complex operation and should be done manually if needed.
-- +goose StatementEnd
