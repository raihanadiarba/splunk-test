-- +goose Up
-- +goose StatementBegin

-- Table Definitions --

CREATE TABLE IF NOT EXISTS config
(
    tenant          text            NOT NULL,
    group_class     text            NOT NULL,
    group_id        text            NOT NULL,
    hash            varchar(44)     NOT NULL,
    name            text            NOT NULL,
    content_type    text            NOT NULL,
    file            bytea           NOT NULL,

    PRIMARY KEY ( tenant, name, group_class, group_id )
);

CREATE TABLE IF NOT EXISTS hash
(
    tenant         text            NOT NULL,
    group_class    text            NOT NULL,
    group_id       text            NOT NULL,
    hash           text            NOT NULL,

    PRIMARY KEY ( tenant, group_class, group_id )
);

-- Indices --

CREATE INDEX IF NOT EXISTS idx_config_tenant_class_id
    ON config (tenant, group_class, group_id);

CREATE INDEX IF NOT EXISTS idx_hash_tenant_class_id
    ON hash (tenant, group_class, group_id);

-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin
DROP TABLE IF EXISTS config;
DROP TABLE IF EXISTS hash;
-- +goose StatementEnd
