-- +goose Up
-- +goose StatementBegin

-- Table Definitions --


ALTER TABLE agents
    ADD COLUMN IF NOT EXISTS remote_config_status text,
    ADD COLUMN IF NOT EXISTS remote_config_error text;


-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin


ALTER TABLE agents
    DROP COLUMN IF EXISTS remote_config_error,
    DROP COLUMN IF EXISTS remote_config_status;

-- +goose StatementEnd
