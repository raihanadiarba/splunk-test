-- +goose Up
-- +goose StatementBegin
UPDATE agents
SET instance_name = hostname
WHERE group_class = 'edge'
  AND instance_name IS NULL
  AND hostname IS NOT NULL;

UPDATE agents AS splunk_edge_agent
SET hostname = edge_agent.hostname,
    instance_name = edge_agent.hostname
FROM agents AS edge_agent
WHERE edge_agent.group_class = 'edge'
  AND splunk_edge_agent.group_class = 'splunk-edge'
  AND EXISTS (
    SELECT 1
    FROM jsonb_array_elements(splunk_edge_agent.agent_description::jsonb->'identifyingAttributes') AS attr
    WHERE attr->>'key' = 'supervisor_id'
      AND attr->'value'->>'stringValue' = edge_agent.agent_id::text
  )
  AND (
    splunk_edge_agent.hostname IS DISTINCT FROM edge_agent.hostname OR
    splunk_edge_agent.instance_name IS DISTINCT FROM edge_agent.hostname
  );
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
-- This is a data backfill that can't be meaningfully reversed.
-- +goose StatementEnd