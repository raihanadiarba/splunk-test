-- add column to track the agent's "instance name" displayed in the ui.
--  → standalone agents:  machine's hostname
--  → docker agents:      container id
--  → kubernetes agents:  pod name

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents ADD COLUMN IF NOT EXISTS instance_name text;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents DROP COLUMN IF EXISTS instance_name;
-- +goose StatementEnd
