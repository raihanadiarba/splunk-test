-- Add pre_update_statuses column to compare package statuses before and after a new package update
-- Generally only updated right before a package update (and checked shortly after), not continuously updated

-- +goose Up
-- +goose StatementBegin
ALTER TABLE agents
ADD COLUMN IF NOT EXISTS pre_update_state jsonb;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents
DROP COLUMN IF EXISTS pre_update_state;
-- +goose StatementEnd
