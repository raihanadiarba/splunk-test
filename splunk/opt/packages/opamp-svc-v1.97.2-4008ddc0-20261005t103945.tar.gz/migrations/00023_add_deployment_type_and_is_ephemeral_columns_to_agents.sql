-- add columns to track the agent's deployment type & ephemerality.
--  → deployment_type: indicates how the agent is deployed (e.g., standalone, docker kubernetes).
--  → is_ephemeral: indicates whether the agent is temporary or persistent in nature. this value is
--    derived from deployment_type & will be used to determine pruning frequency & filtering in the ui.

-- +goose Up
-- +goose StatementBegin
CREATE TYPE agent_deployment_type AS ENUM ('standalone', 'docker', 'kubernetes');
ALTER TABLE agents ADD COLUMN IF NOT EXISTS deployment_type agent_deployment_type DEFAULT 'standalone' NOT NULL;
ALTER TABLE agents ADD COLUMN IF NOT EXISTS is_ephemeral boolean DEFAULT false NOT NULL;
-- +goose StatementEnd


-- +goose Down
-- +goose StatementBegin
ALTER TABLE agents DROP COLUMN IF EXISTS is_ephemeral;
ALTER TABLE agents DROP COLUMN IF EXISTS deployment_type;
DROP TYPE IF EXISTS agent_deployment_type;
-- +goose StatementEnd
