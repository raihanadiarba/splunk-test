-- +goose Up
-- +goose StatementBegin
-- Table Modifications --
ALTER TABLE metrics ALTER COLUMN agent_id TYPE TEXT;
ALTER TABLE agent_desired_packages ALTER COLUMN agent_id TYPE TEXT;
ALTER TABLE agents ALTER COLUMN agent_id TYPE TEXT;
-- +goose StatementEnd

-- +goose Down
-- +goose StatementBegin

-- Drop constraints --
ALTER TABLE metrics DROP CONSTRAINT fk_agents;
ALTER TABLE metrics DROP CONSTRAINT metrics_pkey;

ALTER TABLE agent_desired_packages DROP CONSTRAINT fk_agents;
ALTER TABLE agent_desired_packages DROP CONSTRAINT agent_desired_packages_pkey;

ALTER TABLE agents DROP CONSTRAINT agents_pkey;

-- Existing data --
UPDATE agents SET agent_id = LEFT(agent_id, 36) WHERE LENGTH(agent_id) > 36;
UPDATE metrics SET agent_id = LEFT(agent_id, 36) WHERE LENGTH(agent_id) > 36;
UPDATE agent_desired_packages SET agent_id = LEFT(agent_id, 36) WHERE LENGTH(agent_id) > 36;

-- Table Modifications --
ALTER TABLE metrics ALTER COLUMN agent_id TYPE VARCHAR(36);
ALTER TABLE agent_desired_packages ALTER COLUMN agent_id TYPE VARCHAR(36);
ALTER TABLE agents ALTER COLUMN agent_id TYPE VARCHAR(36);

-- Recreate constraints --
ALTER TABLE agents ADD PRIMARY KEY (tenant, agent_id);

ALTER TABLE metrics ADD PRIMARY KEY (tenant, agent_id);
ALTER TABLE metrics ADD CONSTRAINT fk_agents FOREIGN KEY (tenant, agent_id)
    REFERENCES agents (tenant, agent_id)
    ON DELETE CASCADE;

ALTER TABLE agent_desired_packages ADD PRIMARY KEY (tenant, agent_id);
ALTER TABLE agent_desired_packages ADD CONSTRAINT fk_agents FOREIGN KEY (tenant, agent_id)
    REFERENCES agents (tenant, agent_id)
    ON DELETE CASCADE;

-- +goose StatementEnd
